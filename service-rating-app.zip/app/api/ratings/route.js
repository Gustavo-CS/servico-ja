import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

/**
 * Rota POST - Cadastrar uma avaliação
 */
export async function POST(req) {
  const { professionalId, score, comment } = await req.json();

  if (!professionalId || !score) {
    return NextResponse.json({ error: 'Dados incompletos.' }, { status: 400 });
  }

  const rating = await prisma.rating.create({
    data: {
      professionalId,
      score,
      comment,
    },
  });

  return NextResponse.json(rating);
}

/**
 * Rota GET - Obter média de avaliações
 * Ex: /api/ratings?professionalId=1
 */
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const professionalId = Number(searchParams.get('professionalId'));

  if (!professionalId) {
    return NextResponse.json({ error: 'ID do profissional não informado.' }, { status: 400 });
  }

  const ratings = await prisma.rating.findMany({
    where: { professionalId },
  });

  const average =
    ratings.reduce((acc, curr) => acc + curr.score, 0) / (ratings.length || 1);

  return NextResponse.json({
    average: average.toFixed(1),
    totalRatings: ratings.length,
    ratings,
  });
}